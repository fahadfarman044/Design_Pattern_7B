/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Composition;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author fa20-bse-044
 */
class Book
{
public String name;
public String author;
public String type;
Book(String name, String author, String type)
{
this.name = name;
this.author = author;
this.type = type;
}
}

class College_Library
{
private final List<Book> bks;
College_Library (List<Book> bks)
{
this.bks = bks;
}
public List<Book> totalBooks(){
return bks;
}
}

public class Main {
public static void main (String[] args)
{
Book b1 = new Book("A Passage to Pakistan.","cities", "Literature");
Book b2 = new Book("Beloved", " ", "Fiction");
Book b3 = new Book("the Making of the Modern World", "", "History");

List<Book> bks = new ArrayList<Book>();
bks.add(b1);
bks.add(b2);
bks.add(b3);
College_Library lib = new College_Library(bks);
List<Book> books = lib.totalBooks();
for(Book bb : books){
System.out.println("Name of the book is : " + bb.name + " Book Author is : " + bb.author + " Book Type is : "+
bb.type);
}
}
}