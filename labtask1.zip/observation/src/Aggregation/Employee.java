/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Aggregation;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author fa20-bse-044
 */
class Employee
{
String name;
int emp_id ;
String dept;
Employee(String name, int emp_id, String dept)
{
this.name = name;
this.emp_id = emp_id;
this.dept = dept;
System.out.println("Employee name is "+ name);
System.out.println("Employee id is" + emp_id);
System.out.println("Employee department is "+ dept);
}
}

class Department
{
String dept_name;
private List<Employee> emps;
Department(String name, List<Employee> emps)
{
this.dept_name = dept_name;
this.emps = emps;
}
public List<Employee> EmployeeRecord()
{
return emps;
}
}

class Main
{
public static void main (String[] args)
{
Employee e1 = new Employee("Faizan", 1001, "Development");
Employee e2 = new Employee("Fahad", 1002, "Testing");
Employee e3 = new Employee("Hashir", 1003, "HR");

List <Employee> dev = new ArrayList<Employee>();
dev.add(e1);

List <Employee> test = new ArrayList<Employee>();
test.add(e2);

List <Employee> hr = new ArrayList<Employee>();
hr.add(e3);
}
}