/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author fa20-bse-044
 */
class  TestEagleInterfaces  {
public  static  void  main(String[] args)  {
Eagle myEagle =  new Eagle();

myEagle.eat();
myEagle.sound();
myEagle.fly();

System.out.println("Number of legs: "  + Bird.numberOfLegs);
System.out.println("Outer covering: "  + Bird.outerCovering);
}
}
