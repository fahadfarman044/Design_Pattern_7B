/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author fa20-bse-044
 */
abstract  class  Animal  {

abstract  void  move();
abstract  void  eat();

void  label()  {
System.out.println("Animal's cute:");
}
}
