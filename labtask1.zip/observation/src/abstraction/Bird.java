/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author fa20-bse-044
 */
class  Bird  extends Animal {

    static String numberOfLegs;
    static String outerCovering;
void  move()  {
System.out.println("birds drink water .");
}
void  eat()  {
System.out.println("Eats birdfood.");
}
}