/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstraction;

/**
 *
 * @author fa20-bse-044
 */
class  Eagle  implements Animals, Birds {
public  void  eat()  {
System.out.println("Eats reptiles and amphibians and also eats birds .");
}
public  void  sound()  {
System.out.println("Has a high-pitched whistling sound.");
}
public  void  fly()  {
System.out.println("Flies up to 10,000 feet.");
}
}