/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Inheritance;

/**
 *
 * @author fa20-bse-044
 */
class  Bird  {
public String reproduction =  "egg";
public String outerCovering =  "feather";
public  void  flyUp()  {
System.out.println("Flying up...");
}
public  void  flyDown()  {
System.out.println("Flying down...");
}
}
class  Eagle  extends Bird {
public String name =  "eagle";
public  int lifespan = 15;
}
