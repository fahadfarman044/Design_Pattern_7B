/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polymorphism;

/**
 *
 * @author fa20-bse-044
 */
class  Animal  {
public  void  eat()  {
System.out.println("This animal eats insects.");
}
}
class  Birds  extends Animal {
public  void  eat()  {
System.out.println("This bird eats seeds.");
}
}