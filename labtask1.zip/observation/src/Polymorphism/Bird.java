/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Polymorphism;

/**
 *
 * @author fa20-bse-044
 */
class  Bird  {
public  void  fly()  {
System.out.println("The bird is flying.");
}
public  void  fly(int height)  {
System.out.println("The bird is flying "  + height +  " feet high.");
}
public  void  fly(String name,  int height)  {
System.out.println("The "  + name +  " is flying "  + height +  " feet high.");
}

    void eat() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
}